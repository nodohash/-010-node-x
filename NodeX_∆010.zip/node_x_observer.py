import datetime

def emitir_observacion(nodo, lat, lon, mensaje):
    now = datetime.datetime.now()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
    registro = f"[∆010] [{nodo}] [{lat}/{lon}] [{timestamp}] [“{mensaje}”]\n"
    with open("observaciones.log", "a") as f:
        f.write(registro)
    print("Observación registrada.")

# Ejemplo de uso
emitir_observacion("F-86 NODE-X", "39.4745N", "0.4018W", "Presión asimétrica en eje norte – patrón tríadico detectado")
